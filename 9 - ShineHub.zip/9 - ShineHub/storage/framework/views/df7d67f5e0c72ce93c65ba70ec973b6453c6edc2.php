<?php $__env->startSection('content'); ?>
    <div class="body_content">
        <div class="panel-heading"><h1>Employees Addresses <i class="fa fa-home"></i></h1></div>
            <div class="panel-body table-responsive">

                <router-view name="addressIndex"></router-view>
                <router-view></router-view>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>